====================================================
           ThrottlerOS v1.0.0 Stable
  Localhost Process Throttler & Priority Scheduler
====================================================

Quick Start (Windows):
1. Right-click install.vbs and choose Open (or run install.bat as Administrator).
2. Double-click run.vbs to launch silently in the background without a console window.
3. Open http://127.0.0.1:8742 in any browser.

Quick Start (Linux / macOS):
1. Run ./install.sh
2. Run ./run.sh (or ./run.sh --lan for network access)
3. Open http://127.0.0.1:8742

Features:
- Non-destructive process freezing via kernel suspension (proc.suspend / proc.resume)
- Shortest-Job-First (SJF) priority task scheduling
- Segregated columns for user apps vs system background tasks
- 100% offline and loopback privacy (0 telemetry)
